var name = "Spencer";

console.log(name)